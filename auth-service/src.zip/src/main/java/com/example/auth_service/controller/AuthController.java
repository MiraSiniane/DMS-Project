package com.example.auth_service.controller;

import com.example.auth_service.dto.AuthResponse;
import com.example.auth_service.dto.LoginRequest;
import com.example.auth_service.dto.SignupRequest;
import com.example.auth_service.model.Department;
import com.example.auth_service.model.User;
import com.example.auth_service.service.AuthService;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> signup(
            @RequestBody SignupRequest request,
            @RequestHeader("Authorization") String token
    ) {
        // Only Superadmin can access this endpoint (enforced via SecurityConfig)
        return ResponseEntity.ok(authService.signup(request));
    }
    @GetMapping("/whoami")
    public Map<String, Object> whoAmI(@AuthenticationPrincipal UserDetails user) {
        return Map.of(
            "username", user.getUsername(),
            "authorities", user.getAuthorities()
        );
    }
    @GetMapping("/test-protected")  // Add this endpoint
    public String testProtected() {
        return "This is a protected endpoint";
    }
    
}