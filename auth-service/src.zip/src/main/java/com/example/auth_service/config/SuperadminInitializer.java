package com.example.auth_service.config;

import com.example.auth_service.model.Role;
import com.example.auth_service.model.User;
import com.example.auth_service.repository.RoleRepository;
import com.example.auth_service.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component
@RequiredArgsConstructor
public class SuperadminInitializer implements ApplicationRunner {
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(ApplicationArguments args) {
        // Ensure all roles exist
        createRoleIfMissing(Role.RoleType.SUPERADMIN);
        createRoleIfMissing(Role.RoleType.ADMIN);
        createRoleIfMissing(Role.RoleType.USER);

        System.out.println("\n=== Role Verification ===");
        System.out.println("SUPERADMIN exists: " + 
            roleRepository.existsByName(Role.RoleType.SUPERADMIN));
        System.out.println("ADMIN exists: " + 
            roleRepository.existsByName(Role.RoleType.ADMIN));
        System.out.println("USER exists: " + 
            roleRepository.existsByName(Role.RoleType.USER));
        
        // Create superadmin user if not exists
        if (userRepository.findByEmail("superadmin@docms.com").isEmpty()) {
            User superadmin = User.builder()
                .name("Super Admin")
                .email("superadmin@docms.com")
                .password(passwordEncoder.encode("SuperAdmin123!"))
                .position("System Owner")
                .role(roleRepository.findByName(Role.RoleType.SUPERADMIN).get())
                .status("active")
                .build();
            userRepository.save(superadmin);
        }
    }

    private void createRoleIfMissing(Role.RoleType roleType) {
        if (roleRepository.findByName(roleType).isEmpty()) {  // ← Changed to use findByName
            Role role = new Role();
            role.setName(roleType);
            roleRepository.save(role);
            System.out.println("Created role: " + roleType.name());
        }
    }
}