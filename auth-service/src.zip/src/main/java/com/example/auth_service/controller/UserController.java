package com.example.auth_service.controller;

import com.example.auth_service.dto.DepartmentAssignmentDTO;
import com.example.auth_service.dto.UserUpdateDTO;
import com.example.auth_service.model.User;
import com.example.auth_service.repository.DepartmentRepository;
import com.example.auth_service.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {
    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;

    @PostMapping("/assign-departments")
    public User assignDepartments(
            @RequestBody DepartmentAssignmentDTO assignment,
            @AuthenticationPrincipal UserDetails userDetails) {
        // Verify SUPERADMIN role
        if (!userDetails.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_SUPERADMIN"))) {
            throw new RuntimeException("Only superadmin can assign departments");
        }

        User user = userRepository.findById(assignment.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setDepartments(departmentRepository.findAllById(assignment.getDepartmentIds()));
        return userRepository.save(user);
    }


    // Edit user
    @PutMapping("/{userId}")
    public ResponseEntity<User> updateUser(
        @PathVariable Long userId,
        @RequestBody UserUpdateDTO userUpdateDTO,
        @AuthenticationPrincipal UserDetails userDetails) {
        
        if (!userDetails.getAuthorities().stream()
            .anyMatch(auth -> auth.getAuthority().equals("ROLE_SUPERADMIN"))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, 
                "Only superadmin can edit users");
        }
        
        User existingUser = userRepository.findById(userId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
        
        // Update editable fields
        existingUser.setName(userUpdateDTO.getName());
        existingUser.setEmail(userUpdateDTO.getEmail());
        existingUser.setPosition(userUpdateDTO.getPosition());
        existingUser.setAddress(userUpdateDTO.getAddress());
        existingUser.setPhone(userUpdateDTO.getPhone());
        
        return ResponseEntity.ok(userRepository.save(existingUser));
    }
    

    // Delete user
    @DeleteMapping("/{userId}")
    @Transactional
    public ResponseEntity<Void> deleteUser(
        @PathVariable Long userId,
        @AuthenticationPrincipal UserDetails userDetails) {
        
        verifySuperAdmin(userDetails);
        
        if (!userRepository.existsById(userId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
        }
        
        userRepository.deleteById(userId);
        return ResponseEntity.noContent().build();
    }

    private void verifySuperAdmin(UserDetails userDetails) {
        if (!userDetails.getAuthorities().stream()
            .anyMatch(auth -> auth.getAuthority().equals("ROLE_SUPERADMIN"))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Only superadmin can perform this action");
        }
    }
}