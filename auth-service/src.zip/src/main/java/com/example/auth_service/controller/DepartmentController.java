package com.example.auth_service.controller;

import com.example.auth_service.model.Department;
import com.example.auth_service.repository.DepartmentRepository;
import com.example.auth_service.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/departments")
@RequiredArgsConstructor
public class DepartmentController {
    private final DepartmentRepository departmentRepository;
    private final UserRepository userRepository;  // Added repository

    @PostMapping
    public ResponseEntity<Department> createDepartment(
            @RequestBody Department department,
            @AuthenticationPrincipal UserDetails userDetails) {
        // Verify SUPERADMIN role
        if (!userDetails.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_SUPERADMIN"))) {
            throw new RuntimeException("Only superadmin can create departments");
        }

        if (departmentRepository.existsByName(department.getName())) {
            throw new RuntimeException("Department already exists");
        }

        return ResponseEntity.ok(departmentRepository.save(department));
    }

    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Department> getDepartmentById(@PathVariable Long id) {
        return ResponseEntity.ok(departmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Department not found")));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Department> updateDepartment(
        @PathVariable Long id,
        @RequestBody Department departmentDetails,
        @AuthenticationPrincipal UserDetails userDetails) {
        
        // Verify SUPERADMIN role
        if (!userDetails.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_SUPERADMIN"))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Only superadmin can update departments");
        }

        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Department not found"));

        // Check if new name already exists (excluding current department)
        if (departmentRepository.existsByNameAndIdNot(departmentDetails.getName(), id)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Department name already exists");
        }

        department.setName(departmentDetails.getName());
        return ResponseEntity.ok(departmentRepository.save(department));
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<?> deleteDepartment(
        @PathVariable Long id,
        @AuthenticationPrincipal UserDetails userDetails) {
        
        // Verify SUPERADMIN role
        if (!userDetails.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_SUPERADMIN"))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, 
                "Only superadmin can delete departments");
        }

        Department department = departmentRepository.findWithUsersById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, 
                "Department not found"));

        // Automatically unassign all users
        department.getUsers().forEach(user -> 
            user.getDepartments().remove(department));
        userRepository.saveAll(department.getUsers());

        departmentRepository.delete(department);
        return ResponseEntity.noContent().build();
    }
}