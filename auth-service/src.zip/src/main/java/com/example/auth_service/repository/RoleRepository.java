package com.example.auth_service.repository;

import com.example.auth_service.model.Role;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
    // For enum-based search
    Optional<Role> findByName(Role.RoleType name);
    
    // For exists check (add this new method)
    boolean existsByName(Role.RoleType name);
}