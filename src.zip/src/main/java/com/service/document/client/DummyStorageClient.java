package com.service.document.client;

import com.service.document.dto.FileUploadResponseDTO;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class DummyStorageClient implements StorageClient {

    @Override
    public FileUploadResponseDTO upload(MultipartFile file) {
        return new FileUploadResponseDTO(
            "dummy-file.pdf",
            "http://localhost:9000/fake-bucket/dummy-file.pdf",
            file.getContentType(),
            file.getSize()
        );
    }

    @Override
    public String getPresignedUrl(String key) {
        return "http://localhost:9000/fake-bucket/" + key;
    }

    @Override
    public void deleteFile(String key) {
        // nothing to do in dummy mode
    }
}
